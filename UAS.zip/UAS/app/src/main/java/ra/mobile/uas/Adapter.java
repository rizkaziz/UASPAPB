package ra.mobile.uas;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {
    private List<Item> List;
    public Adapter(List<Item> List) {
        this.List = List;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // Inflate rv
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item, parent, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull Adapter.ViewHolder holder, int position) {
        Item item = List.get(position);
        holder.ActivityTextView.setText(item.getActivity());
        holder.timeTextView.setText(item.getTime());
    }

    @Override
    public int getItemCount() {
        return List.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView ActivityTextView;
        TextView timeTextView;
        public ViewHolder(View itemView) {
            super(itemView);
            ActivityTextView = itemView.findViewById(R.id.tvActivity);
            timeTextView = itemView.findViewById(R.id.tvTime);
        }
    }
}
