package ra.mobile.uas;

public class Item {
    private int id;
    private String activity;
    private String time;

    public Item(int id, String activity, String time) {
        this.id = id;
        this.activity = activity;
        this.time = time;
    }
    public int getId() {
        return id;
    }
    public String getActivity() {
        return activity;
    }
    public String getTime() {
        return time;
    }
}
