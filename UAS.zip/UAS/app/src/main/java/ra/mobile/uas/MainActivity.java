package ra.mobile.uas;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView rv;
    private List<Item> List = new ArrayList<>();
    private Adapter Adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rv = findViewById(R.id.rvToDoList);
        Adapter = new Adapter(MainActivity.this.List);
        fetchData();
        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setAdapter(Adapter);
    }

    private void fetchData() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        boolean isConnected = activeNetworkInfo != null && activeNetworkInfo.isConnected();
        if (isConnected) {
            // Show loading state
            ProgressDialog p = new ProgressDialog(MainActivity.this);
            p.setMessage("Harap tunggu...");
            p.setCancelable(false);
            p.show();
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Thread.sleep(1500);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    } runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            p.dismiss();
                            String url = "https://mgm.ub.ac.id/todo.php";
                            RequestQueue queue = Volley.newRequestQueue(MainActivity.this);
                            StringRequest stringRequest = new StringRequest(Request.Method.GET, url,new Response.Listener<String>() {
                                        @Override
                                        public void onResponse(String response) {
                                            // Try to parse JSON
                                            try {
                                                JSONArray Array = new JSONArray(response);
                                                Log.d("json", Array.toString());
                                                for (int i = 0; i < Array.length(); i++) {
                                                    JSONObject jsonObject = Array.getJSONObject(i);
                                                    int id = jsonObject.getInt("id");
                                                    String what = jsonObject.getString("what");
                                                    String time = jsonObject.getString("time");
                                                    Item item = new Item(id, what, time);
                                                    List.add(item);
                                                }
                                                Adapter.notifyDataSetChanged();
                                            } catch (JSONException e) {
                                                e.printStackTrace();
                                            }
                                        }
                                    }, new Response.ErrorListener() {
                                        @Override
                                        public void onErrorResponse(VolleyError error) {
                                            error.printStackTrace();
                                        }
                                    });
                            queue.add(stringRequest);
                        }
                    });
                }
            }).start();
        } else {
            AlertDialog.Builder b = new AlertDialog.Builder(MainActivity.this);
            b.setTitle("Offline").setMessage("Tidak ada koneksi internet").setCancelable(false).setNegativeButton("Retry", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            fetchData();
                        }
                    }).setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            finish();
                        }
                    }).show();
        }
    }
}